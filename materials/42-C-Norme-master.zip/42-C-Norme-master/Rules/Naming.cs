﻿using System;
namespace appRegex.Rules
{
    
}
